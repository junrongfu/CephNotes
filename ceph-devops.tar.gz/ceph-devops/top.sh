#!/bin/bash

export COLUMNS=200
date=`date +"%Y%m%d%H"`
my_avg_load=`uptime | awk -F ':' '{print $NF}' | awk -F ',' '{print $(NF-2)}'`
top_logfile="/data/top/$date.log"
script_dir=`dirname $0`
cpus=`grep "processor" /proc/cpuinfo -c`
loads=$(($cpus / 2 ))

if [ `echo "$my_avg_load > $loads" | bc` -eq 1 ];then
    for i in {1..3}
    do
        top -b -n 1 -c -s | head -n 80 >> $top_logfile
        mpstat -P ALL 1 1 >> $top_logfile
        iostat -x 1 2 >> $top_logfile
        free -m >> $top_logfile
	memory_capacity_in_kb=$(cat /proc/meminfo | grep MemTotal | awk '{print $2}')
	memory_capacity_in_mb=$((memory_capacity_in_kb / 1024))
	memory_usage_in_bytes=$(cat /sys/fs/cgroup/memory/memory.usage_in_bytes)
	memory_usage_in_mb=$((memory_usage_in_bytes / 1048576))
	memory_total_inactive_file=$(cat /sys/fs/cgroup/memory/memory.stat | grep total_inactive_file | awk '{print $2}')
	
	memory_working_set=${memory_usage_in_bytes}
	if [ "$memory_working_set" -lt "$memory_total_inactive_file" ];
	then
	    memory_working_set=0
	else
	    memory_working_set_in_bytes=$((memory_usage_in_bytes - memory_total_inactive_file))
	    memory_working_set=$((memory_working_set_in_bytes / 1048576))
	fi
	
	memory_available_in_bytes=$((memory_capacity_in_mb - memory_working_set))
	memory_available_in_mb=$((memory_available_in_bytes ))
	
	echo "kubelet judges the memory as:" >> $top_logfile
	echo "memory.capacity_in_mb $memory_capacity_in_mb mb"  >> $top_logfile
	echo "memory.usage_in_mb $memory_usage_in_mb mb"  >> $top_logfile
	echo "memory.total_inactive_file $memory_total_inactive_file"  >> $top_logfile
	echo "memory.working_set $memory_working_set mb"  >> $top_logfile
	echo "memory.available_in_mb $memory_available_in_mb mb"  >> $top_logfile


        if [ -f /etc/redhat-release -a -z "`awk '{if($3<6){print $0}}' /etc/redhat-release`" ]
        then
            echo '' >> $top_logfile
            echo "sort by memory used:" >> $top_logfile
            top -b -n 1 -c -s -a | head -n 50 >> $top_logfile
            echo '' >> $top_logfile
        else
            echo '' >> $top_logfile
            echo "sort by memory used:" >> $top_logfile
            ps aux | sort -nrk 4 | head -n 50 >> $top_logfile
            echo '' >> $top_logfile
        fi

        iotop -oPbt -n 2 >> $top_logfile

        if [ -f $script_dir/top_extra.sh ]
        then
            sh $script_dir/top_extra.sh >> $top_logfile
        fi

        echo "" >> $top_logfile
        sleep 1
    done
else
        top -b -n1 -c -s | head -n 50 >> $top_logfile
        mpstat -P ALL 1 1 >> $top_logfile
        iostat -x 1 2 >> $top_logfile
        free -m >> $top_logfile
        memory_capacity_in_kb=$(cat /proc/meminfo | grep MemTotal | awk '{print $2}')
        memory_capacity_in_mb=$((memory_capacity_in_kb / 1024))
        memory_usage_in_bytes=$(cat /sys/fs/cgroup/memory/memory.usage_in_bytes)
        memory_usage_in_mb=$((memory_usage_in_bytes / 1048576))
        memory_total_inactive_file=$(cat /sys/fs/cgroup/memory/memory.stat | grep total_inactive_file | awk '{print $2}')

        memory_working_set=${memory_usage_in_bytes}
        if [ "$memory_working_set" -lt "$memory_total_inactive_file" ];
        then
            memory_working_set=0
        else
            memory_working_set_in_bytes=$((memory_usage_in_bytes - memory_total_inactive_file))
            memory_working_set=$((memory_working_set_in_bytes / 1048576))
        fi

        memory_available_in_bytes=$((memory_capacity_in_mb - memory_working_set))
        memory_available_in_mb=$((memory_available_in_bytes ))

	echo "kubelet judges the memory as:" >> $top_logfile
        echo "memory.capacity_in_mb $memory_capacity_in_mb mb"  >> $top_logfile
        echo "memory.usage_in_mb $memory_usage_in_mb mb"  >> $top_logfile
        echo "memory.total_inactive_file $memory_total_inactive_file"  >> $top_logfile
        echo "memory.working_set $memory_working_set mb"  >> $top_logfile
        echo "memory.available_in_mb $memory_available_in_mb mb"  >> $top_logfile
        iotop -oPbt -n 2 >> $top_logfile
fi

echo " " >> $top_logfile
