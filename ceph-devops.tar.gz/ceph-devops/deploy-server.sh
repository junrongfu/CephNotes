#!/bin/bash
set -e 

pwd=$(dirname $0)
# 部署服务器脚本，用于部署ceph服务器需要的基本组件
# 系统调整
setenforce 0
sed -i 's/SELINUX=enforcing/SELINUX=disabled/g' /etc/selinux/config
systemctl stop firewalld.service
systemctl disable firewalld.service
# 用户添加
useradd cephfsd
echo "cephfsd ALL = (root,ceph) NOPASSWD:ALL" | sudo tee /etc/sudoers.d/cephfsd
chmod 0440 /etc/sudoers.d/cephfsd
sudo -u cephfsd sh -c 'mkdir -p ~/.ssh; touch ~/.ssh/authorized_keys; chmod 0700 ~/.ssh; chmod 0600 ~/.ssh/authorized_keys'
# 安装ceph软件
curl -o /etc/yum.repos.d/ceph-nautilus.repo http://mirrors.myhexin.com/repository/raw/repo/ceph-nautilus.repo
yum install -y ceph ceph-deploy ceph-radosgw ceph-mgr-dashboard
yum install -y htop sysstat iotop iftop ntpdate net-tools
# 安装node_exporter
adduser --system --no-create-home --shell=/sbin/nologin node_exporter
yum install -y golang-github-prometheus-node-exporter
systemctl enable node_exporter.service
systemctl start node_exporter.service
# 关闭swap
sed -Ei 's/^(UUID=[a-zA-Z0-9-]+\s+swap)/#\1/g' /etc/fstab

# 修改内核参数
#echo 262144 > /sys/module/nf_conntrack/parameters/hashsize
cat << EOF >> /etc/sysctl.conf
net.ipv4.tcp_max_syn_backlog = 102400
net.ipv4.tcp_synack_retries = 2
net.ipv4.tcp_syn_retries = 2
net.ipv4.tcp_fin_timeout = 5
net.ipv4.tcp_keepalive_time = 600
net.ipv4.tcp_max_orphans = 262144
net.ipv4.tcp_mem  = 4194304 6291456 8388608
net.ipv4.tcp_rmem = 4096 87380 16777216
net.ipv4.tcp_wmem = 4096 65535 16777216
net.ipv4.tcp_no_metrics_save = 1
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_timestamps = 1
net.ipv4.tcp_retrans_collapse = 0
net.ipv4.tcp_window_scaling = 1
net.ipv4.tcp_max_tw_buckets = 30000
net.ipv4.ip_local_port_range = 1024  65535

net.core.rmem_default = 1048576
net.core.netdev_max_backlog = 102400
net.core.rmem_max = 16777216
net.core.wmem_default = 1048576
net.core.wmem_max = 16777216
net.core.somaxconn = 65535
fs.file-max = 2097152
vm.swappiness = 0
vm.max_map_count=458752
net.ipv4.neigh.default.gc_thresh1 = 512
net.ipv4.neigh.default.gc_thresh2 = 2048
net.ipv4.neigh.default.gc_thresh3 = 4096
net.ipv4.ip_forward = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1

net.netfilter.nf_conntrack_max=1048576
net.nf_conntrack_max=1048576
net.netfilter.nf_conntrack_tcp_timeout_fin_wait=30
net.netfilter.nf_conntrack_tcp_timeout_time_wait=30
net.netfilter.nf_conntrack_tcp_timeout_close_wait=15
net.netfilter.nf_conntrack_tcp_timeout_established=300

kernel.pid_max = 458752
kernel.threads-max = 458752
kernel.pid_max = 458752
kernel.threads-max = 458752
EOF

# 开启top日志
mkdir -p /data/top/
cp $pwd/top.sh /data/top/top.sh
cp $pwd/cron_ops /etc/cron.d/cron_ops

# 不同集群的差异化处理
cluster=
function aton()
{
    echo $1 | gawk '{c=256; split($0, ip, "."); print ip[4] + ip[3] * c + ip[2] * c^2 + ip[1] * c^3}'
}
ip=$(hostname -I)
ipn=$(aton $ip)
networks=( "test|10.10.80.0/22" "cbas|172.21.54.0/23" "prod|192.168.0.0/16" )
for nsmap in ${networks[@]}
do
    gw=$(echo $nsmap | awk -F'|' '{print $2}')
    mask=$(ipcalc -m $gw | awk -F= '{print $2}')
    maskn=$(aton $mask)
    gwn=$(aton $gw)
    if [ $((ipn & maskn)) == $gwn ]
    then
        eth=bond0
        cluster=$(echo $nsmap | awk -F'|' '{print $1}')
        break
    fi
done

if [ "$cluster" == "" ]
then
    echo "$ip have not in a valid vlan"
    exit 1
fi
sh $pwd/cluster/$cluster.sh


# check
firewalld=$(systemctl | grep firewalld | wc -l)
if [ $firewalld != 0 ]
then
    echo "firewalld.service not close"
    exit 1
fi

authmod=$(ls -ahl /home/cephfsd/.ssh/authorized_keys | awk '{print $1}')
if [ "$authmod" != "-rw-------" ]
then
    echo "authorized keys mode error: " $authmod
    exit 1
fi
