#!/bin/bash
set -e 

sh $(dirname $0)/stop-rebalance.sh
systemctl stop ceph-*.target
echo '10jqka@123^&*ceph' | passwd --stdin
halt
