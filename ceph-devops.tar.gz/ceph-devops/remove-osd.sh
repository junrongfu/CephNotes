#!/bin/bash
osdnum=$1
if [ "$osdnum" == "" ]
then
    echo "please set osd num"
    exit 1
fi
ceph osd df name osd.$osdnum
echo '===================================='
echo "Continue removing osd.$osdnum: Y/n"
echo '===================================='
read yn
if [ "$yn" != 'Y' ]
then
    exit 0
fi
use=$(ceph osd df name osd.$osdnum | tail -3 | head -1 | awk '{if ($17 > 0) print 1}')
if [ "$use" != "" ]
then
    echo "There is still data in osd.$osdnum, cannot be deleted"
    exit 1
fi
ceph osd out $osdnum
systemctl stop ceph-osd@$osdnum.service
sleep 1
ceph osd crush remove osd.$osdnum
ceph auth del osd.$osdnum
ceph osd rm osd.$osdnum
