#!/bin/bash
echo '
[default]
host_base = 127.0.0.1:7480
host_bucket =
use_https = false
' > ~/.s3cfg
