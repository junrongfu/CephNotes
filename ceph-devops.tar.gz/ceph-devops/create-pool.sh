#!/bin/bash
name=$1
if [ "$name" == "" ]
then
    echo "please set pool name"
    exit 1
fi
rule=$2
if [ "$rule" == "" ]
then
    echo "please set pool crush rule name"
    exit 1
fi
ceph osd pool create $name $pg $pg $rule
