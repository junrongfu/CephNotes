#!/bin/bash
help() {
    echo "Usage:"
    echo "mkbucket.sh -u username -p bucket_prefix -n bucket_num"
    echo "Description:"
    echo "username: 需要创建bucket的用户名"
    echo "bucket_prefix: bucket的前缀，最终bucket名称的格式为\$username.\$bucket_prefix.\$num"
    echo "bucket_num: 需要创建的bucket数量，将会创建从0 ~ \$bucket_num -1的bucket"
    exit -1
}
 
 
while getopts 'u:p:n:h' OPT; do
    case $OPT in
        u) username="$OPTARG";;
        p) bucket_prefix="$OPTARG";;
        n) bucket_num="$OPTARG";;
        h) help;;
        ?) help;;
    esac
done
if [ "$username" == "" ]
then
	echo '请设置需要创建bucket的用户名'
	exit 1
fi
if [ "$bucket_prefix" == "" ]
then
	echo '请设置需要创建bucket的前缀'
	exit 1
fi
if [ "$bucket_num" == "" ] || [ "$bucket_num" -lt 0 ]
then
	echo '请设置需要创建bucket的数量，必须大于0'
	exit 1
fi
access_key=$(radosgw-admin user info --uid $username | grep access_key | awk -F'"' '{print $4}')
if [ "$access_key" == "" ]
then
	echo '用户"'$username'"不存在'
	exit 1
fi
secret_key=$(radosgw-admin user info --uid $username | grep secret_key | awk -F'"' '{print $4}')

max_buckets=$(radosgw-admin user info --uid $username | grep max_buckets | awk -F: '{print $2}' | awk -F, '{gsub(/\s/, "", $1); print $1}')
bucket="${username}.${bucket_prefix}"
info=$(radosgw-admin bucket stats --bucket=$bucket 2>&1)
if [ $? == 0 ]
then
	owner=$(echo "$info" | grep -E '^\s+"owner":' | awk -F'"' '{print $4}')
	if [ "$owner" == "$username" ]
	then
		exit 0
	else
		echo "$bucket is not $username bucket"
	fi
fi
max_buckets=$((max_buckets+1))
radosgw-admin user modify --uid $username --max-buckets $max_buckets 1>/dev/null
s3cmd mb s3://$bucket --access_key $access_key --secret_key $secret_key
radosgw-admin bucket reshard --bucket $bucket --num-shards $bucket_num

#for i in $(seq $bucket_num)
#do
#	n=$((i-1))
#	bucket="${username}.${bucket_prefix}.$n"
#	info=$(radosgw-admin bucket stats --bucket=$bucket 2>&1)
#	if [ $? == 0 ]
#	then
#		owner=$(echo "$info" | grep -E '^\s+"owner":' | awk -F'"' '{print $4}')
#		if [ "$owner" == "$username" ]
#		then
#			continue
#		else
#			echo "$bucket is not $username bucket"
#			exit 1
#		fi
#	fi
#	max_buckets=$((max_buckets+1))
#	radosgw-admin user modify --uid $username --max-buckets $max_buckets 1>/dev/null
#	s3cmd mb s3://$bucket --access_key $access_key --secret_key $secret_key
#	if [ $? != 0 ]
#	then
#		max_buckets=$((max_buckets-1))
#	fi
#done
