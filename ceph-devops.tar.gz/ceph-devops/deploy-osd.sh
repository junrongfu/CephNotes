#!/bin/bash
hostname=$1
if [ "$hostname" == "" ]
then
    echo "please specify hostname"
    exit 1
fi
ping $hostname -c 1
if [ $? != 0 ]
then
    exit 1
fi

disks=$(echo $2 | tr "," "\n")
if [ "$disks" == "" ]
then
    echo "please specify disks"
    exit 1
fi

for disk in ${disks[@]}
do
    ceph-deploy  osd create --data /dev/$disk $hostname
done
