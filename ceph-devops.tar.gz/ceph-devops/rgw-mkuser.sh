#!/bin/sh
set -e

help() {
    echo "Usage:"
    echo "createuser.sh -u username -m maxsize"
    echo "Description:"
    echo "username: 需要创建bucket的用户名"
    echo "max_size: 该用户下所有对象存储空间的最大值，例如: 1G，500M"
    exit -1
}
 
 
while getopts 'u:m:h' OPT; do
    case $OPT in
        u) username="$OPTARG";;
        m) maxsize="$OPTARG";;
        h) help;;
        ?) help;;
    esac
done
if [ "$username" == "" ]
then
	echo "用户名为空，请设置用户名，用户名为业务树上的名称"
	exit 1
fi
if [ "$maxsize" == "" ]
then
	echo "请设置用户最大存储空间"
	exit 1
fi 
# 创建rgw账号
radosgw-admin user create --uid $username --display-name $username --max-buckets 1 1>/dev/null
# 设置容量quota
radosgw-admin quota enable --quota-scope user --uid $username
radosgw-admin quota set --quota-scope user --uid $username --max-size $maxsize
radosgw-admin user info --uid $username

access_key=$(radosgw-admin user info --uid $username | grep access_key | awk -F'"' '{print $4}')
if [ "$access_key" == "" ]
then
        echo '用户"'$username'"不存在'
        exit 1
fi
secret_key=$(radosgw-admin user info --uid $username | grep secret_key | awk -F'"' '{print $4}')
s3cmd mb s3://deny-bucket.${username} --access_key=$access_key --secret_key=$secret_key
