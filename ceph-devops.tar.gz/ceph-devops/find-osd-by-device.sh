#!/bin/bash
device=$1
echo $device | grep -E '^/dev/' > /dev/null
if [ $? != 0 ]
then
    device=/dev/$device
fi
ceph-volume lvm list $device --format=json | grep '"ceph.osd_id"' | awk -F'"' '{print $4}'
