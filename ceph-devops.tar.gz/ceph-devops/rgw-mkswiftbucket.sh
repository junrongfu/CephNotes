#!/bin/bash
access=$1
if [ "$access" == "" ]
then
	echo "access_key is empty"
	exit 1
fi
bucket=$2
if [ "$bucket" == "" ]
then
	echo "bucket is empty"
	exit 1
fi
public=$3
info=$(radosgw-admin user info --access_key $1)
if [ $? != 0 ]
then
	echo "access is not found"
	exit 1
fi
secret=$(echo "$info" | grep $access -C 2 | grep secret_key | awk -F'"' '{print $4}')
s3cmd mb s3://$bucket --access_key $access --secret_key $secret
if [ "$public" == "1" ]
then
	s3cmd setpolicy $(dirname $0)/read.policy s3://$bucket --access_key $access --secret_key $secret
	s3cmd setacl s3://$bucket -P --access_key $access --secret_key $secret
fi
