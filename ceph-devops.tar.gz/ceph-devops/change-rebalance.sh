#!/bin/bash
speed=$1
backfill=1
active=1
single=1
rsleep=1
minpglog=1
maxpglog=2

if [ "$speed" == 5 ]
then
    active=1
elif [ "$speed" == 25 ]
then
    backfill=3
    active=5
    single=5
    rsleep=0.25
elif [ "$speed" == 50 ]
then
    backfill=3
    active=20
    single=20
    rsleep=0.15
elif [ "$speed" == 75 ]
then
    backfill=3
    active=30
    single=30
    rsleep=0
elif [ "$speed" == 100 ]
then
    backfill=3
    active=50
    single=50
    rsleep=0
    minpglog=1500
    maxpglog=10000
else
    echo "only support 5, 25, 50, 75, 100 speed"
    exit 1
fi

ceph tell osd.* config set osd_max_backfills $backfill
ceph tell osd.* config set osd_recovery_max_active $active
ceph tell osd.* config set osd_recovery_max_single_start $single
ceph tell osd.* config set osd_recovery_sleep $rsleep
ceph tell osd.* config set osd_min_pg_log_entries $minpglog
ceph tell osd.* config set osd_max_pg_log_entries $maxpglog
