#!/bin/bash
username=$1
if [ "$username" == "" ]
then
	echo "$username is empty"
	exit 1
fi

bucket=$2
if [ "$bucket" == "" ]
then
	echo "bucket is empty"
	exit 1
fi

access_key=$(radosgw-admin user info --uid $username | grep access_key | awk -F'"' '{print $4}')
if [ "$access_key" == "" ]
then
        echo '用户"'$username'"不存在'
        exit 1
fi
secret_key=$(radosgw-admin user info --uid $username | grep secret_key | awk -F'"' '{print $4}')
if [ "$access_key" == "" ]
then
        echo '用户"'$username'"不存在'
        exit 1
fi

bucket="${username}.${bucket}"
s3cmd setpolicy $(dirname $0)/read.policy s3://$bucket --access_key $access_key --secret_key $secret_key
s3cmd setacl s3://$bucket -P --access_key $access_key --secret_key $secret_key
