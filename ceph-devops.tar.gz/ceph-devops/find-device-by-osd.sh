#!/bin/bash
osdnum=$1
fsid=$(ceph osd find $osdnum | grep osd_fsid | awk -F'"' '{print $4}')
pv=$(lvs | grep $fsid | awk '{print $2}')
pvs | grep $pv | awk '{print $1}'
