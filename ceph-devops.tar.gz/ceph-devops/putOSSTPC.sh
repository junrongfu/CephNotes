#!/bin/bash

userId=$1
serviceID=""
serviceIP="10.204.148.198"

if [ "$userId" = "" ]
then
  echo "userid is null"
  exit
fi


#test
serviceID=$(curl -XPOST http://${serviceIP}:8080/api/v1/account -d'{"account_name":"'"$userId"'", "cluster":"test", "type":"hxceph"}' |awk -F "\"" '{print $8}')
curl -s -o /dev/null -X POST http://${serviceIP}:8080/api/v1/account/$serviceID/service -d '{"data":[{"service_name":"hxceph-oss-base-beta", "num":1, "pay_cycle": "yearly", "auto": true}]}'

# prod
serviceID=$(curl -XPOST http://${serviceIP}:8080/api/v1/account -d'{"account_name":"'"$userId"'", "cluster":"prod", "type":"hxceph"}' |awk -F "\"" '{print $8}')
curl -s -o /dev/null -X POST http://${serviceIP}:8080/api/v1/account/$serviceID/service -d '{"data":[{"service_name":"hxceph-oss-base", "num":1, "pay_cycle": "yearly", "auto": true}]}'



