#!/bin/bash
eth=bond0
ipmask=10.200.0.0/15
gateway=192.168.216.11
echo "$ipmask via $gateway" >> /etc/sysconfig/network-scripts/route-$eth
ip route add $ipmask via $gateway dev $eth

ntp=$(cat /etc/crontab | grep ntpdate)
if [ "$ntp" == "" ]
then
    echo "*/5 * * * * root ntpdate 192.168.0.2 > /dev/null" >> /etc/crontab
fi

pwd=$(dirname $0)
cat $pwd/prod.id_rsa.pub >> /home/cephfsd/.ssh/authorized_keys
