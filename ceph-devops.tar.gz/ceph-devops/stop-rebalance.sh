#!/bin/bash
for i in noout nobackfill norecover norebalance;
do 
    ceph osd set $i 
done
